
CREATE DATABASE schooldb
use schooldb

CREATE TABLE student 
(
id INT PRIMARY KEY,
name VARCHAR (50) NOT NULL,
gender VARCHAR (50) NOT NULL,
DOB datetime NOT NULL,
total_score INT NOT NULL,
city VARCHAR (50) NOT NULL)
create procedure  dept_avg_sal_new @dept varchar(100) as
select department,avg(Salary) as salary from tbl002_emp
where Department=@dept
group by Department


--exec dept_avg_sal_new @dept='Finance'
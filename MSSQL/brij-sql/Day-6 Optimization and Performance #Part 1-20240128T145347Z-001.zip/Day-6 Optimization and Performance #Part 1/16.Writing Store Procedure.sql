
create procedure avg_sal_new as
select department,avg(Salary) as salary from tbl002_emp
group by Department


exec avg_sal_new
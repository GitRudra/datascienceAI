select coalesce(NULL,NULL,'Intellipaat',NULL,NULL,'Waseem');
select coalesce('Shilpi',NULL,NULL,'Intellipaat',NULL);


--select * from 
update dept
set Manager=null
where Department='Analytics'


select isnull(department,'No manager'),isnull(manager,'No manager') from dept
select *
,iif(Country='India','Native','NRI') AS residential_Status,
iif(Department='Analytics','Data Practice Domain','Others') as Dept_status
,iif(Gender='Male','One','Two') as test,
CASE WHEN Gender='Male' or Country='India' then
'Multiple condition test true for or'
else
'nothing'
end case_Testing,
Department,Department
from tbl002_emp



use vrinda
SELECT New_StudentID, MarksNo, MarksRecd
FROM
(SELECT New_StudentID,
Marks1, Marks2, Marks3
FROM New_Student) as stu
UNPIVOT
(MarksRecd FOR MarksNo IN (Marks1, Marks2, Marks3)
) AS mrks
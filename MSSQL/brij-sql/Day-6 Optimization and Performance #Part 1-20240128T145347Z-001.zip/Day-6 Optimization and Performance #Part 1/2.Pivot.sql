select * from 
  (SELECT country,Department,Gender,Salary FROM [vrinda].[dbo].[tbl002_emp]) as t
PIVOT  
(Avg(Salary)
FOR Gender IN ([Male],[Female])) as sahil_Table









use vrinda
CREATE CLUSTERED INDEX [NonClusteredIndex-20230401] ON [dbo].[new_student]
(
	[New_Studentid] ASC
	
)




USE [schooldb]


CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230401-192403] ON [dbo].[student]
(
	[id] ASC,
	[name] ASC,
	[gender] ASC
)




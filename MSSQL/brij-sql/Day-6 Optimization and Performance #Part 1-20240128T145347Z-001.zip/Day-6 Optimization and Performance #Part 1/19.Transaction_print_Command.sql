begin try
begin transaction
update tbl002_emp set salary=50 where gender='Male'

update tbl002_emp set
salary=195/0 where employee_name='Female'
commit transaction Print 'transaction committed'
end try begin catch
rollback transaction
print 'transaction rolledback' end catch

--use DB005_PROD_SQL
create view VW01_country_Dept_gend_salary as
--create view <view name> and as then query
/*
=====================================================
CREATED_ON :08 July 23 @ 20:20
Created_by: Brij Arora
Objective : to get the summarize value of salary at Country,
Department and Gender level

Modified by :Brij
Modified on :08 Jul 23 @ 20:20
Reason of modification : to add average salary
Logic change of modification : column added avg(salary)
=====================================================
*/
select 
country,
Department,
Gender,
sum(salary) as Total_Salary
,avg(salary) as avg_salary
from tbl001_emp
group by Country,Department,Gender


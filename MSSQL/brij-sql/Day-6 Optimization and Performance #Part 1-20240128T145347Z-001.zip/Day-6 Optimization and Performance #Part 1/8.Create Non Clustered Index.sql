USE [schooldb]

CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230401-192402] ON [dbo].[student]
(
		[name] ASC
	)




select Department,employee_name,salary,
iif(Maximum_Salary_For_Department=Salary,'Highest Paid with in department','Not') as Highest_Salary,
iif(Average_Salary_For_Department<=Salary,'Higher than average in dept','Lower than average in dept') as Higher_Than_avg
from
(select Department,
employee_name,
salary,
(select max(salary) from tbl002_emp as e2
where e1.Department=e2.Department
group by Department) as Maximum_Salary_For_Department,
(select avg(salary) from tbl002_emp as e3
where e1.Department=e3.Department
group by Department) as Average_Salary_For_Department

from tbl002_emp  as e1
) as evt
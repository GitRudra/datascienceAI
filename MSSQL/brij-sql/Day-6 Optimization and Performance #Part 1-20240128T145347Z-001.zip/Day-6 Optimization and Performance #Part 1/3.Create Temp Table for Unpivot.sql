
CREATE TABLE New_Student
(
New_StudentID int ,
Marks1 float,
Marks2 float,
Marks3 float
)

INSERT INTO New_Student VALUES (1, 5.6, 7.3, 4.2)
INSERT INTO New_Student VALUES (2, 4.8, 7.9, 6.5)
INSERT INTO New_Student VALUES (3, 6.8, 6.6, 8.9)
INSERT INTO New_Student VALUES (4, 8.2, 9.3, 9.1)
INSERT INTO New_Student VALUES (5, 6.2, 5.4, 4.4)

SELECT * FROM New_Student


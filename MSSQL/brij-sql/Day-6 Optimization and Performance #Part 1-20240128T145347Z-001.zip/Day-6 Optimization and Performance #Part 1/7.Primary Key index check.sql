exec sp_helpindex student

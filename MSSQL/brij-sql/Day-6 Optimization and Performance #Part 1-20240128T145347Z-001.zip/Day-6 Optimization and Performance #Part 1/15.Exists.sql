select * from tbl002_emp as e1
where exists 
(select  department from dept  as e2
where e1.department=e2.Department)
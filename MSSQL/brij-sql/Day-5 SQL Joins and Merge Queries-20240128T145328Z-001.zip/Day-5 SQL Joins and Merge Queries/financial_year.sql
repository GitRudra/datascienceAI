use master
Select FIRST_DAY_OF_MONTH, datepart (mm, FIRST_DAY_OF_MONTH) as Calender_Month,  --column 1DATEADD(MM,-3, FIRST_DAY_OF_MONTH) as mid_tier_column, --column 2.1Datepart(MM, DATEADD(MM,-3, FIRST_DAY_OF_MONTH)) as Financial_month -- column 2.2
,case when datepart(mm,FIRST_DAY_OF_MONTH)<4 then
convert(varchar,datepart(yyyy,FIRST_DAY_OF_MONTH)-1)+'-'+right(convert(varchar,DATEPART(yy,FIRST_DAY_OF_MONTH)),2)
else 
convert(varchar,datepart(yyyy,FIRST_DAY_OF_MONTH))+'-'+right(convert(varchar,DATEPART(yy,FIRST_DAY_OF_MONTH)+1),2)
end fin_year 
from fy_test
order by 1
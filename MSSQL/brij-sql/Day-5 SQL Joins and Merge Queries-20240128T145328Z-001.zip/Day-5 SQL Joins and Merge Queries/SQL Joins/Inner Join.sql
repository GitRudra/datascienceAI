select * from tbl002_emp
inner join dept
on tbl002_Emp.department=dept.department



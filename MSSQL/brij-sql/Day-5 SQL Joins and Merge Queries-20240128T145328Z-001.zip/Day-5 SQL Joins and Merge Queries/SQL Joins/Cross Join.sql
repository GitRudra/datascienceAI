select * from tbl002_emp,dept
--on tbl002_Emp.department=dept.department



select * from tbl002_emp
full outer join dept
on tbl002_Emp.department=dept.department



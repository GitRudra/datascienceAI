select * from TargetProducts

MERGE TargetProducts AS Target
USING SourceTable AS Source
ON Source.ProductID = Target.ProductID
WHEN NOT MATCHED BY Source THEN
DELETE;

select * from TargetProducts


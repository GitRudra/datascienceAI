select * from TargetProducts

MERGE TargetProducts AS Target
USING SourceTable AS Source
ON Source.ProductID = Target.ProductID
WHEN MATCHED THEN UPDATE SET
Target.ProductName= Source.ProductName ,
Target.Price= Source.Price;

select * from TargetProducts
Truncate table TargetProducts

insert into [TargetProducts]
(ProductID,ProductName,Price)
values
(1,'Clock',10.00),
(2,'Lamp',20.00),
(5,'Bed',50.00),
(6,'Cupboard',300.00)
MERGE TargetProducts AS Target
USING SourceTable	AS Source
ON Target.ProductID=Source.ProductID  
WHEN NOT MATCHED BY Target THEN
INSERT (ProductID,ProductName, Price)
VALUES (Source.ProductID,Source.ProductName, Source.Price);
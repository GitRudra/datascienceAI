USE [vrinda]
GO

/****** Object:  Table [dbo].[sales]    Script Date: 25-03-2023 23:01:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SourceTable](
	[ProductID] [int] NULL,
	[ProductName] [varchar](100) NULL,
	[Price] [decimal](18, 0) NULL
) 
GO



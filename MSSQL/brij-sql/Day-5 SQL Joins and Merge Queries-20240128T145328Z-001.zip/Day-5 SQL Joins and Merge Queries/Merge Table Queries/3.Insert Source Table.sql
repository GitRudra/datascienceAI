insert into [SourceTable]
(ProductID,ProductName,Price)
values
(1,'Table',100.00),
(2,'Desk',80.00),
(3,'Chair',50.00),
(4,'Computer',300.00)
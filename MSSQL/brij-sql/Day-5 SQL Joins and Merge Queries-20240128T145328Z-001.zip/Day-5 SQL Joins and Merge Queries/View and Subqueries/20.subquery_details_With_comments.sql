select * from
--for selecting the output and showing as a table, all the alias in next query will become column name here

(
--select statement first part from table 
select department,
employee_name,
Salary,
--select statement second part for getting max salary of department and joining this with
--outer table
(select max(salary) from tbl002_emp as subquery_table
where main_Table.department=subquery_table.department
group by Department) as Highest_salary_in_Department,
--select statement third part of max salary of company
(select max(salary) from tbl002_emp as subquery_2) as Highest_salary_in_company
from tbl002_emp as main_Table
--post closing bracket it's mandatory to give name in order to run 
) as outer_table
--left join with dept table and output table
left join dept
on outer_table.department=dept.Department
--have more column, which have highest paid salary in Department

select Department,max(Salary),avg(Salary) from tbl002_emp
group by Department

select * from tbl002_emp


select Department,
employee_name,
salary,
(select max(salary) from tbl002_emp as e2
where e1.Department=e2.Department
group by Department) as Maximum_Salary_For_Department
,(select avg(salary) from tbl002_emp as e3
where e1.Department=e3.Department
group by Department) as Average_Salary_For_Department
from tbl002_emp  as e1
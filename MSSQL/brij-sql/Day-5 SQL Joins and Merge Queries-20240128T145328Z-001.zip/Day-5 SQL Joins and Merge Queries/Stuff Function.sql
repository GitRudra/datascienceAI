SELECT Store_Name, STUFF(Store_Name, 7, 8, '-store') as Stuffed_column from Store_details



